sap.ui.define([
	"com/swcc/Template/test/unit/controller/App.controller"
], function () {
	"use strict";
});