sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.swcc.Template.controller.LandingView", {
		onInit: function () {
			this.oRouter = this.getOwnerComponent().getRouter();

		},
		onApprove: function () {
			//this.oRouter.navTo("DetailView");
			//alert("Hello");
			this.getOwnerComponent().getTargets().display("DetailView");
		}
	})
})